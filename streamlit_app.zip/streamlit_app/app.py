import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

DATA_DIR = Path(__file__).parent / "star_data"

st.set_page_config(page_title="Financial Transactions - Time Analysis", layout="wide")


@st.cache_data
def load_star():
    # Load the star schema tables and join the fact to the dimensions
    # needed for this page (time, symbol, transaction type).
    dim_time = pd.read_csv(DATA_DIR / "dim_time.csv", parse_dates=["date"])
    dim_symbol = pd.read_csv(DATA_DIR / "dim_symbol.csv")
    dim_tt = pd.read_csv(DATA_DIR / "dim_transaction_type.csv")
    fact = pd.read_csv(DATA_DIR / "fact_transactions.csv")
    return (fact
            .merge(dim_time, on="time_key")
            .merge(dim_symbol, on="symbol_key")
            .merge(dim_tt, on="transaction_type_key"))


def style_axes(ax):
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)


def hbar(series, title, xlabel):
    # Horizontal bar chart, largest value on top, with value labels.
    s = series.sort_values()
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.barh(s.index.astype(str), s.values, color="#4C72B0")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    style_axes(ax)
    for i, v in enumerate(s.values):
        ax.text(v, i, f" {int(v)}", va="center")
    fig.tight_layout()
    return fig


star = load_star()

st.title("Financial Transactions - Time Analysis")

# --- Date range filter (default: full year 2024) ---
year_start = pd.Timestamp("2024-01-01").date()
year_end = pd.Timestamp("2024-12-31").date()

selected = st.date_input(
    "Date range",
    value=(year_start, year_end),
    min_value=year_start,
    max_value=year_end,
)

# While the user is still picking, date_input may return a single date.
if isinstance(selected, (tuple, list)) and len(selected) == 2:
    start_date, end_date = selected
else:
    start_date, end_date = year_start, year_end

# Filter to the selected range; all charts below use this filtered data.
in_range = ((star["date"] >= pd.Timestamp(start_date)) &
            (star["date"] <= pd.Timestamp(end_date)))
trades = star[in_range & star["transaction_type"].isin(["BUY", "SELL"])]

if trades.empty:
    st.warning("No BUY/SELL transactions in the selected date range.")
    st.stop()

st.metric("BUY+SELL transactions in range", int(trades["transaction_count"].sum()))

# --- Line chart: total BUY+SELL transactions over time ---
daily = trades.groupby("date")["transaction_count"].sum().sort_index()
fig, ax = plt.subplots(figsize=(11, 4))
ax.plot(daily.index, daily.values, color="#4C72B0")
ax.set_title("Total BUY+SELL transactions over time")
ax.set_ylabel("Transactions")
style_axes(ax)
fig.autofmt_xdate()
st.pyplot(fig)

# --- Top symbols and sectors side by side ---
top_symbols = trades.groupby("symbol")["transaction_count"].sum().nlargest(3)
top_sectors = trades.groupby("sector")["transaction_count"].sum().nlargest(5)

c1, c2 = st.columns(2)
with c1:
    st.pyplot(hbar(top_symbols, "Top 3 symbols by transactions", "Transactions"))
with c2:
    st.pyplot(hbar(top_sectors, "Top 5 sectors by transactions", "Transactions"))

# --- Top industries (full width: longer labels) ---
top_industries = trades.groupby("industry")["transaction_count"].sum().nlargest(5)
st.pyplot(hbar(top_industries, "Top 5 industries by transactions", "Transactions"))
