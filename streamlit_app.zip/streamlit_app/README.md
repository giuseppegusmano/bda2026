# Financial Transactions - Streamlit Dashboard

Page 1 - Time Analysis.

## Run
```
pip install -r requirements.txt
streamlit run app.py
```

The `star_data/` folder contains the star schema tables exported from the notebook
(dimensions + fact). The app joins the fact to the dimensions and shows, for the
selected date range: total BUY+SELL transactions over time, top 3 symbols,
top 5 sectors and top 5 industries by transaction count.
